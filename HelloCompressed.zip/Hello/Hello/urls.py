from home import views
from django.contrib import admin
from django.urls import path, include


admin.site.site_header = "Arpan Admin"
admin.site.site_title = "Arpan Admin Portal"
admin.site.index_title = "Welcome to Arpan's Django Portal"

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", views.index, name=""),
    path("contact/", views.contact, name="contact"),
    path("service", views.services, name=""),
    path("about", views.about),
]
